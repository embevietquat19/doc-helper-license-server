// Popup v2: nút nguồn to, chế độ Basic/Optimal/Complete,
// bật/tắt từng nhóm lọc, whitelist theo site.
document.addEventListener('DOMContentLoaded', async () => {
  const $ = (id) => document.getElementById(id);
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let host = '';
  try { host = new URL(tab?.url || '').hostname; } catch (e) {}
  $('host').textContent = host || '—';

  const MODE_DESC = {
    basic: 'Chỉ chặn quảng cáo. Nhẹ nhất, ít vỡ trang nhất.',
    optimal: 'Chặn quảng cáo + chặn theo dõi. Khuyên dùng.',
    complete: 'Thêm chặn nội dung phiền nhiễu. Chặn mạnh nhất, có thể vỡ vài trang.',
    custom: 'Bật/tắt lẻ từng nhóm lọc bên dưới.',
  };

  async function refresh() {
    const s = await chrome.runtime.sendMessage({ type: 'get-state' });
    if (!s) return s;
    $('blockedToday').textContent = s.blockedToday || 0;
    $('adsSkipped').textContent = s.adsSkipped || 0;
    $('elementsHidden').textContent = s.elementsHidden || 0;
    $('listsVersion').textContent = s.listsVersion ? `(list ngày ${s.listsVersion})` : '';
    $('totalRules').textContent = `${(s.totalRules || 0).toLocaleString('vi-VN')} rule đang bật`;
    $('powerBtn').classList.toggle('on', s.enabled !== false);
    $('powerBtn').classList.toggle('off', s.enabled === false);
    document.querySelectorAll('.mode').forEach(b => b.classList.toggle('active', b.dataset.mode === s.mode));
    $('modeDesc').textContent = MODE_DESC[s.mode] || MODE_DESC.custom;
    const box = $('rulesets');
    box.innerHTML = '';
    for (const [id, meta] of Object.entries(s.rulesetMeta || {})) {
      const row = document.createElement('label');
      row.className = 'ruleset';
      row.innerHTML = `<input type="checkbox" ${s.rulesets[id] ? 'checked' : ''}> <span></span> <span class="count">${meta.count.toLocaleString('vi-VN')} rule</span>`;
      row.querySelector('span').textContent = meta.label;
      row.querySelector('input').addEventListener('change', async () => {
        await chrome.runtime.sendMessage({ type: 'toggle-ruleset', id });
        refresh();
      });
      box.appendChild(row);
    }
    const wl = (s.whitelist || []).includes(host);
    $('whitelistBtn').classList.toggle('active', wl);
    $('whitelistBtn').textContent = wl ? 'Bật chặn lại trên trang này' : 'Tắt chặn trên trang này';
    $('statusNote').textContent = s.enabled === false
      ? 'Đã tắt chặn quảng cáo trên mọi trang.'
      : wl ? `Đã tắt chặn trên ${host}. Quảng cáo sẽ hiện lại trên trang này.`
      : 'Đang chặn quảng cáo trên trang này.';
    return s;
  }

  await refresh();
  loadVideos();
  checkForUpdate(false);

  // --- Báo bản mới online (giống Doc Helper): popup hỏi server license
  // xem có bản Blueberry mới hơn không (GET /api/latest-blueberry,
  // cache 6 giờ trong storage.local). Có bản mới thì hiện banner
  // "Đã có bản mới" + nút tải file ZIP; bấm "Để sau" thì ẩn banner cho
  // tới khi có bản mới hơn nữa. Extension cài tay nên Chrome không tự
  // update — đây là cách duy nhất người dùng cũ biết có bản mới.
  // Không có mạng / server chưa có thông tin thì im lặng, không báo lỗi.
  const UPDATE_URL = 'https://license.digimar.site/api/latest-blueberry';
  const UPDATE_CACHE_TTL = 6 * 60 * 60 * 1000;
  const currentVersion = chrome.runtime.getManifest().version || '';
  let latestUpdate = null;

  function compareVersions(a, b) {
    const pa = String(a || '').split('.').map((x) => parseInt(x, 10) || 0);
    const pb = String(b || '').split('.').map((x) => parseInt(x, 10) || 0);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      const d = (pa[i] || 0) - (pb[i] || 0);
      if (d !== 0) return d > 0 ? 1 : -1;
    }
    return 0;
  }
  function renderUpdateBanner(latest) {
    const banner = $('updateBanner');
    if (!banner) return;
    latestUpdate = latest;
    $('updateTitle').textContent = 'Đã có bản mới v' + latest.version;
    $('updateNotes').textContent = latest.notes ? ' — ' + latest.notes : '';
    banner.hidden = false;
  }
  async function checkForUpdate(force) {
    if (!currentVersion) return null;
    let info = {};
    try { info = (await chrome.storage.local.get('bb_update_check')).bb_update_check || {}; } catch (e) {}
    const fresh = !force && info.checkedAt && (Date.now() - info.checkedAt) < UPDATE_CACHE_TTL && info.latest;
    let latest = fresh ? info.latest : null;
    if (!latest) {
      try {
        const res = await fetch(UPDATE_URL);
        if (res && res.ok) {
          const data = await res.json();
          if (data && data.ok && data.version && data.url) {
            latest = { version: data.version, url: data.url, notes: data.notes || '' };
          }
        }
      } catch (e) { latest = null; }
      try { await chrome.storage.local.set({ bb_update_check: { checkedAt: Date.now(), latest, dismissedVersion: info.dismissedVersion || '' } }); } catch (e) {}
    }
    if (!latest) return null;
    if (compareVersions(latest.version, currentVersion) <= 0) return latest;
    if (info.dismissedVersion === latest.version) return latest;
    renderUpdateBanner(latest);
    return latest;
  }
  $('btnUpdateDownload').addEventListener('click', () => {
    if (!latestUpdate || !latestUpdate.url) return;
    chrome.tabs.create({ url: latestUpdate.url });
  });
  $('btnUpdateDismiss').addEventListener('click', async () => {
    $('updateBanner').hidden = true;
    if (!latestUpdate) return;
    let info = {};
    try { info = (await chrome.storage.local.get('bb_update_check')).bb_update_check || {}; } catch (e) {}
    try { await chrome.storage.local.set({ bb_update_check: { checkedAt: info.checkedAt || Date.now(), latest: info.latest || latestUpdate, dismissedVersion: latestUpdate.version } }); } catch (e) {}
  });
  $('checkUpdateBtn').addEventListener('click', async () => {
    const status = $('updateStatus');
    status.textContent = 'Đang kiểm tra…';
    const latest = await checkForUpdate(true);
    if (!latest) { status.textContent = 'Chưa kiểm tra được, thử lại sau.'; return; }
    if (compareVersions(latest.version, currentVersion) <= 0) {
      status.textContent = `Đã là bản mới nhất (v${currentVersion}).`;
    } else {
      status.textContent = '';
    }
  });

  async function loadVideos() {
    const box = $('videoList');
    if (!tab?.id) return;
    let res;
    try {
      res = await chrome.tabs.sendMessage(tab.id, { type: 'get-videos' });
    } catch (e) { return; } // Tab không có content script tải video (vd: trang Chrome)
    const videos = res?.videos || [];
    if (!videos.length) return;
    box.innerHTML = '';
    videos.forEach((v, i) => {
      const row = document.createElement('div');
      row.className = 'video-row';
      const mins = v.duration ? `${Math.floor(v.duration / 60)}:${String(v.duration % 60).padStart(2, '0')}` : '';
      row.innerHTML = `<span class="video-title"></span><button class="video-dl">Tải</button>`;
      row.querySelector('.video-title').textContent = `${v.platform || 'video'} ${i + 1}${mins ? ' · ' + mins : ''}`;
      row.querySelector('.video-dl').addEventListener('click', async () => {
        await chrome.runtime.sendMessage({ type: 'download-video', url: v.url, filename: `${v.platform || 'video'}-${new Date().toISOString().slice(0, 10)}.mp4` });
        window.close();
      });
      box.appendChild(row);
    });
  }

  $('powerBtn').addEventListener('click', async () => {
    await chrome.runtime.sendMessage({ type: 'toggle-enabled' });
    refresh();
  });
  document.querySelectorAll('.mode').forEach(b => b.addEventListener('click', async () => {
    await chrome.runtime.sendMessage({ type: 'set-mode', mode: b.dataset.mode });
    refresh();
  }));
  $('whitelistBtn').addEventListener('click', async () => {
    if (!host) return;
    await chrome.runtime.sendMessage({ type: 'toggle-whitelist', host });
    refresh();
    if (tab?.id) chrome.tabs.reload(tab.id);
  });
  $('reloadBtn').addEventListener('click', () => { if (tab?.id) chrome.tabs.reload(tab.id); });
});
