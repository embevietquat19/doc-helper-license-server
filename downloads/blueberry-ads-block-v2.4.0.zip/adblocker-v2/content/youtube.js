// Blueberry ADS Block — YouTube
// YouTube phát quảng cáo video từ cùng domain googlevideo.com như video chính,
// nên không chặn được bằng rules network (chặn là hỏng cả video).
// Cách làm ở đây: phát hiện quảng cáo đang chạy -> tua nhanh + tắt tiếng +
// bấm nút Bỏ qua ngay khi hiện, rồi trả lại tốc độ/âm lượng cũ.
// + Ẩn quảng cáo hiển thị (masthead, sidebar, trong feed, overlay).
(() => {
  'use strict';
  if (window.__adblockYT) return;
  window.__adblockYT = true;

  let enabled = true;
  let savedRate = 1;
  let savedMuted = false;
  let savedVolume = 1;
  let adActive = false;
  let skippedCount = 0;

  const HIDE_SELECTORS = [
    'ytd-display-ad-renderer', 'ytd-ad-slot-renderer', 'ytd-promoted-sparkles-text-search-renderer',
    'ytd-promoted-video-renderer', 'ytd-banner-promo-renderer', 'ytd-statement-banner-renderer',
    'ytd-compact-promoted-video-renderer', 'ytd-action-companion-ad-renderer',
    'ytd-in-feed-ad-layout-renderer', '#masthead-ad', '.ytd-masthead-ad',
    'ytd-player-legacy-desktop-watch-ads-renderer', 'ytd-watch-next-secondary-results-renderer ytd-ad-slot-renderer',
    '#player-ads', '.ytp-ad-overlay-container', '.ytp-ad-text-overlay',
    'ytm-companion-ad-renderer', 'ytm-promoted-video-renderer'
  ];

  function player() { return document.querySelector('#movie_player') || document.querySelector('.html5-video-player'); }
  function video() { return document.querySelector('video.html5-main-video') || document.querySelector('video'); }
  function isAdShowing() {
    const p = player();
    if (!p) return false;
    if (p.classList.contains('ad-showing') || p.classList.contains('ad-interrupting')) return true;
    // Dấu hiệu phụ: có nút skip / có chữ "Quảng cáo" trong player
    return !!document.querySelector('.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-ad-player-overlay, .ytp-ad-preview-container');
  }

  function clickSkip() {
    const btns = document.querySelectorAll(
      '.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, button.ytp-ad-skip-button-container'
    );
    for (const b of btns) {
      if (b && b.offsetParent !== null) { b.click(); return true; }
    }
    // Nút "Bỏ qua" dạng text trong overlay
    const all = document.querySelectorAll('.ytp-ad-skip-button-container button, .ytp-ad-text');
    for (const b of all) { if (b && /bỏ qua|skip/i.test(b.textContent || '')) { b.click(); return true; } }
    return false;
  }

  function handleAd() {
    const v = video();
    const p = player();
    if (!v || !p) return;
    const showing = isAdShowing();

    if (showing && !adActive) {
      adActive = true;
      savedRate = v.playbackRate || 1;
      savedMuted = v.muted;
      savedVolume = v.volume;
      // Tắt tiếng + tua nhanh nhất có thể để quảng cáo trôi qua trong tích tắc
      v.muted = true;
      try { v.playbackRate = 16; } catch (e) { v.playbackRate = 4; }
      // Quảng cáo không bấm được nút Skip thì tua tới cuối video quảng cáo
      if (isFinite(v.duration) && v.duration > 0) {
        try { v.currentTime = v.duration - 0.05; } catch (e) {}
      }
      clickSkip();
    } else if (showing && adActive) {
      // Đang trong quảng cáo: giữ tua nhanh, bấm skip liên tục khi nó hiện
      if (v.playbackRate < 8) { try { v.playbackRate = 16; } catch (e) {} }
      if (isFinite(v.duration) && v.duration > 0 && v.currentTime < v.duration - 0.5) {
        try { v.currentTime = v.duration - 0.05; } catch (e) {}
      }
      clickSkip();
    } else if (!showing && adActive) {
      // Quảng cáo vừa hết: trả lại tốc độ + âm lượng cũ
      adActive = false;
      try { v.playbackRate = savedRate || 1; } catch (e) {}
      v.muted = savedMuted;
      if (!savedMuted) v.volume = savedVolume;
      skippedCount++;
      try { chrome.runtime.sendMessage({ type: 'yt-ad-skipped' }); } catch (e) {}
    }
  }

  function hideDisplayAds() {
    for (const sel of HIDE_SELECTORS) {
      document.querySelectorAll(sel).forEach(el => {
        if (el.dataset.abHidden) return;
        el.dataset.abHidden = '1';
        el.style.setProperty('display', 'none', 'important');
      });
    }
    // Quảng cáo trong feed trang chủ / kết quả tìm kiếm / Shorts
    document.querySelectorAll('ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer, ytd-reel-video-renderer').forEach(el => {
      if (el.dataset.abChecked) return;
      el.dataset.abChecked = '1';
      const badge = el.querySelector('.badge-style-type-ad, [aria-label*="Quảng cáo"], [aria-label*="Sponsored"], .ytd-badge-supported-renderer');
      const t = (el.textContent || '').slice(0, 200);
      if (badge || /^\s*(Quảng cáo|Sponsored)\b/i.test(t)) {
        el.style.setProperty('display', 'none', 'important');
      }
    });
  }

  function tick() {
    if (!enabled) return;
    handleAd();
    hideDisplayAds();
  }

  // Trạng thái bật/tắt
  chrome.runtime.sendMessage({ type: 'get-state' }, (s) => { if (s) enabled = s.enabled !== false; });
  chrome.storage.onChanged.addListener((c) => {
    if (c.enabled) enabled = c.enabled.newValue !== false;
  });

  // YouTube là SPA: video đổi mà trang không reload -> cần quan sát liên tục
  const observer = new MutationObserver(() => tick());
  observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });

  // Vòng lặp chính: 500ms/lần — đủ nhanh để bấm Skip ngay khi hiện
  setInterval(tick, 500);
  // Bấm skip ngay khi DOM đổi (nhanh hơn cả interval)
  document.addEventListener('click', () => setTimeout(tick, 50), true);
  tick();
  setTimeout(tick, 1000);
})();
