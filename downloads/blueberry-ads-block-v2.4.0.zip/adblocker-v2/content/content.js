// Blueberry ADS Block — content script cho web thường
// 2 lớp: (1) CSS ẩn sẵn các khung quảng cáo phổ biến, (2) JS quét + xóa/ẩn
// các element quảng cáo mới xuất hiện (SPA, lazy-load) qua MutationObserver.
(() => {
  'use strict';
  if (window.__adblockVN) return;
  window.__adblockVN = true;

  let enabled = true;
  let whitelisted = false;
  let reported = 0;

  const SELECTORS = [
    // Google Ads
    '.adsbygoogle', 'ins.adsbygoogle', '[id^="google_ads"]', '[id*="google_ads"]',
    'iframe[src*="doubleclick"]', 'iframe[src*="googlesyndication"]',
    // Khung quảng cáo theo tên class/id phổ biến
    '[class*="advertisement"]', '[class*="Advertisement"]',
    '[id*="advertisement"]', '[id*="Advertisement"]',
    '[class*="ad-container"]', '[class*="ad-wrapper"]', '[class*="ad-banner"]',
    '[id*="ad-container"]', '[id*="ad-banner"]', '[id*="ad-wrapper"]',
    '.ad-unit', '.ad-slot', '.ad-box', '.ad-label',
    // Taboola / Outbrain / MGID / Revcontent
    '[id*="taboola"]', '[class*="taboola"]',
    '[id*="outbrain"]', '[class*="outbrain"]',
    '[class*="mgid"]', '[class*="revcontent"]',
    // Popunder / overlay quảng cáo
    '[id*="popunder"]', '[class*="popup-ad"]', '[class*="overlay-ad"]',
    // Iframe quảng cáo theo src
    'iframe[src*="ads"]', 'iframe[src*="adservice"]', 'iframe[src*="adnxs"]',
    'iframe[src*="criteo"]', 'iframe[src*="taboola"]', 'iframe[src*="outbrain"]'
  ];

  // Cosmetic theo từng site, biên dịch từ các danh sách lọc đã gộp
  // (content/cosmetic.json, 1.318 domain). Generic đã có trong
  // content/cosmetic.css, đây là phần riêng theo từng site.
  let specificSelectors = [];
  try {
    fetch(chrome.runtime.getURL('content/cosmetic.json')).then(r => r.json()).then(map => {
      const host = location.hostname;
      const parts = host.split('.');
      const candidates = [];
      for (let i = 0; i < parts.length - 1; i++) candidates.push(parts.slice(i).join('.'));
      for (const d of candidates) {
        if (map[d]) specificSelectors.push(...map[d]);
      }
      if (specificSelectors.length) { SELECTORS.push(...specificSelectors); clean(); }
    }).catch(() => {});
  } catch (e) {}

  const HOST_PATTERNS = ['doubleclick.net', 'googlesyndication.com', 'googleadservices.com', 'adnxs.com', 'criteo.com', 'taboola.com', 'outbrain.com', 'adsrvr.org'];

  function isAdSrc(src) {
    if (!src) return false;
    return HOST_PATTERNS.some(h => src.includes(h));
  }

  function report(n) {
    reported += n;
    // Gộp báo cáo: gửi khi đủ 5 rồi reset, để số đếm khớp thực tế
    // (bản cũ chỉ gửi khi tổng đúng bội số của 5 nên hay bị thiếu)
    if (reported >= 5) {
      const send = reported;
      reported = 0;
      try { chrome.runtime.sendMessage({ type: 'ad-blocked', count: send }); } catch (e) {}
    }
  }

  function clean(root = document) {
    if (!enabled || whitelisted || !root.querySelectorAll) return 0;
    let n = 0;
    for (const sel of SELECTORS) {
      let els = [];
      try { els = root.querySelectorAll(sel); } catch (e) { continue; }
      els.forEach(el => {
        if (el.dataset.abHidden) return;
        // Không ẩn element chứa nội dung chính (phòng false positive)
        if (el.closest('main, article, [role="main"]') && el.tagName !== 'IFRAME' && el.tagName !== 'INS') {
          // Chỉ ẩn nếu nó rõ ràng là quảng cáo (có chữ Sponsored/Quảng cáo hoặc là iframe ads)
          const t = (el.textContent || '').slice(0, 80);
          if (!/quảng cáo|sponsored|advertisement/i.test(t)) return;
        }
        el.dataset.abHidden = '1';
        el.style.setProperty('display', 'none', 'important');
        n++;
      });
    }
    // Iframe có src quảng cáo mà selector chưa bắt được
    root.querySelectorAll('iframe').forEach(f => {
      if (f.dataset.abHidden) return;
      if (isAdSrc(f.src)) { f.dataset.abHidden = '1'; f.style.setProperty('display', 'none', 'important'); n++; }
    });
    if (n) report(n);
    return n;
  }

  // Đồng bộ trạng thái bật/tắt + whitelist
  chrome.runtime.sendMessage({ type: 'get-state' }, (s) => {
    if (!s) return;
    enabled = s.enabled !== false;
    whitelisted = !!s.whitelisted;
    if (enabled && !whitelisted) clean();
  });
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.enabled) enabled = changes.enabled.newValue !== false;
    if (changes.whitelist) {
      const host = location.hostname;
      whitelisted = (changes.whitelist.newValue || []).includes(host);
    }
    if (enabled && !whitelisted) clean();
  });

  // Quét định kỳ + khi DOM thay đổi (trang SPA load thêm quảng cáo)
  let scheduled = false;
  function scheduleClean() {
    if (scheduled) return;
    scheduled = true;
    setTimeout(() => { scheduled = false; clean(); }, 300);
  }
  const observer = new MutationObserver((mutations) => {
    for (const m of mutations) {
      if (m.addedNodes && m.addedNodes.length) { scheduleClean(); break; }
    }
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });

  // Chặn mở tab popunder khi click (lớp phòng thủ cuối, chỉ khi link trỏ tới domain ads)
  document.addEventListener('click', (e) => {
    if (!enabled || whitelisted) return;
    const a = e.target.closest('a[href]');
    if (a && isAdSrc(a.href)) { e.preventDefault(); e.stopPropagation(); }
  }, true);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => clean());
  } else {
    clean();
  }
  // Quét lại sau 2s và 5s cho các quảng cáo load chậm
  setTimeout(() => clean(), 2000);
  setTimeout(() => clean(), 5000);
})();
