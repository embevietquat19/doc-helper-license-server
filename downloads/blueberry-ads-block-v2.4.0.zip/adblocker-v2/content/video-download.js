// Tải video mạng xã hội — content script
// Hỗ trợ: Facebook, Instagram, TikTok, X, Threads và các trang có <video>.
// KHÔNG hỗ trợ YouTube: video YouTube dùng DASH (nhiều mảnh riêng lẻ,
// không có 1 file mp4 trực tiếp) và điều khoản YouTube cấm tải.
// Cách hoạt động: gắn nút "Tải video" lên từng video, bấm là tải file
// mp4 đang phát (đúng chất lượng đang xem). Video dạng blob (TikTok,
// một số video Facebook) thì fetch blob rồi tải về máy.
(() => {
  'use strict';
  if (window.__abvnVideoDl) return;
  window.__abvnVideoDl = true;

  const PLATFORM = (() => {
    const h = location.hostname;
    if (h.includes('facebook.com')) return 'facebook';
    if (h.includes('instagram.com')) return 'instagram';
    if (h.includes('tiktok.com')) return 'tiktok';
    if (h.includes('twitter.com') || h.includes('x.com')) return 'x';
    if (h.includes('threads.net')) return 'threads';
    if (h.includes('dailymotion.com')) return 'dailymotion';
    return 'video';
  })();

  function filenameFor(url) {
    const date = new Date().toISOString().slice(0, 10);
    let ext = 'mp4';
    try {
      const clean = (url || '').split('?')[0];
      const m = clean.match(/\.([a-z0-9]{2,4})$/i);
      if (m && ['mp4', 'webm', 'mov', 'mkv'].includes(m[1].toLowerCase())) ext = m[1].toLowerCase();
    } catch (e) {}
    const title = (document.title || 'video').replace(/[\\/:*?"<>|]+/g, '').trim().slice(0, 40) || 'video';
    return `${PLATFORM}-${date}-${title}.${ext}`;
  }

  function toast(msg) {
    let t = document.querySelector('.abvn-dl-toast');
    if (!t) {
      t = document.createElement('div');
      t.className = 'abvn-dl-toast';
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t._timer);
    t._timer = setTimeout(() => t.classList.remove('show'), 3000);
  }

  function getVideoUrl(video) {
    const cands = [
      video.currentSrc, video.src,
      video.querySelector('source') && video.querySelector('source').src,
      video.getAttribute('src'),
    ];
    for (const u of cands) {
      if (u && typeof u === 'string' && u.length > 4) return u;
    }
    return '';
  }

  function downloadBlobUrl(url, filename) {
    return fetch(url).then(r => {
      if (!r.ok) throw new Error('fetch ' + r.status);
      return r.blob();
    }).then(blob => {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 10000);
    });
  }

  function downloadVideo(video, btn) {
    const setBusy = (t) => { if (btn) btn.textContent = t; };
    let url = getVideoUrl(video);
    if (!url) {
      // Video chưa load src (feed lazy-load): bấm play rồi thử lại sau 800ms
      try { video.play().catch(() => {}); } catch (e) {}
      setTimeout(() => {
        const u2 = getVideoUrl(video);
        if (u2) downloadVideo(video, btn);
        else { toast('Chưa lấy được link video, thử bấm play rồi tải lại.'); setBusy('⬇ Tải video'); }
      }, 800);
      return;
    }
    if (url.includes('.m3u8')) {
      toast('Video livestream (m3u8) chưa hỗ trợ tải.');
      setBusy('⬇ Tải video');
      return;
    }
    const filename = filenameFor(url);
    setBusy('Đang tải…');
    if (url.startsWith('blob:')) {
      downloadBlobUrl(url, filename).then(() => {
        toast('Đang tải video về máy.');
        setBusy('⬇ Tải video');
      }).catch(() => {
        toast('Không tải được video này (link blob đã hết hạn, thử tải lại khi video đang phát).');
        setBusy('⬇ Tải video');
      });
      return;
    }
    try {
      chrome.runtime.sendMessage({ type: 'download-video', url, filename }, () => {
        toast('Đang tải video về máy.');
        setBusy('⬇ Tải video');
      });
    } catch (e) {
      toast('Không tải được video này.');
      setBusy('⬇ Tải video');
    }
  }

  function addButton(video) {
    if (!video || video.dataset.abvnDl) return;
    const url = getVideoUrl(video);
    // Bỏ qua video quảng cáo / video tracking nhỏ xíu
    if (url && /doubleclick|googlesyndication|adservice|taboola|outbrain/i.test(url)) return;
    video.dataset.abvnDl = '1';
    const parent = video.parentElement || video;
    try {
      const cs = getComputedStyle(parent);
      if (cs.position === 'static') parent.style.position = 'relative';
    } catch (e) {}
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'abvn-dl-btn';
    btn.textContent = '⬇ Tải video';
    btn.title = 'Tải video này về máy (đúng chất lượng đang xem)';
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      downloadVideo(video, btn);
    });
    parent.appendChild(btn);
  }

  function scan() {
    document.querySelectorAll('video').forEach(addButton);
  }

  // Popup hỏi danh sách video trên tab hiện tại
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'get-videos') {
      const list = [];
      document.querySelectorAll('video').forEach(v => {
        const url = getVideoUrl(v);
        if (!url || url.includes('.m3u8')) return;
        list.push({ url, title: document.title || PLATFORM, duration: isFinite(v.duration) ? Math.round(v.duration) : 0, platform: PLATFORM });
      });
      sendResponse({ videos: list.slice(0, 10) });
      return true;
    }
    if (msg.type === 'download-blob') {
      const v = [...document.querySelectorAll('video')].find(x => getVideoUrl(x) === msg.url);
      if (v) downloadVideo(v, null);
      sendResponse({ ok: !!v });
      return true;
    }
    return false;
  });

  let scheduled = false;
  function scheduleScan() {
    if (scheduled) return;
    scheduled = true;
    setTimeout(() => { scheduled = false; scan(); }, 400);
  }
  const observer = new MutationObserver(() => scheduleScan());
  observer.observe(document.documentElement, { childList: true, subtree: true });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', scan);
  } else {
    scan();
  }
  setTimeout(scan, 2000);
  setTimeout(scan, 5000);
})();
