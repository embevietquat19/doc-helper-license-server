# Blueberry ADS Block v2.3.1

## Mới trong v2.3.1 — Tự hiện thông báo khi có bản mới

Thêm quyền `notifications` + `alarms`: background kiểm tra bản mới
định kỳ (5 phút sau khi mở Chrome, rồi mỗi 6 giờ, chung cache 6 giờ
với popup). Có bản mới thì tự hiện thông báo Chrome "Đã có bản mới
vX.Y.Z" với 2 nút: bấm **"⬇ Tải bản mới"** (hoặc bấm vào thông báo)
là mở link tải ZIP, bấm **"Để sau"** thì ẩn cho tới khi có bản mới
hơn nữa.

NÓI THẲNG: update thẳng vào extension thì **không làm được** với bản
cài tay (Load unpacked) — Chrome không cho extension tự thay file của
chính nó, không có API nào làm việc đó, `requestUpdateCheck` chỉ có
tác dụng với extension cài từ Chrome Web Store. Thông báo tự động +
1 bấm tải ZIP là mức tối đa; sau khi tải về vẫn cần giải nén đè lên
thư mục cũ rồi bấm Reload trong `chrome://extensions/`. Muốn update
hoàn toàn tự động thì chỉ có cách đăng lên Chrome Web Store, nhưng
lên Store thì phải khai Trader + privacy policy tên thật — đúng lý do
đã không lên Store với Doc Helper.

## Mới trong v2.3.0 — Báo bản mới online (giống Doc Helper)

## Mới trong v2.3.0 — Báo bản mới online (giống Doc Helper)

Extension cài tay nên Chrome không tự update. Từ bản này, mỗi lần mở
popup, extension hỏi server license (`GET
https://license.digimar.site/api/latest-blueberry`, cache 6 giờ) xem
có bản mới hơn không. Có bản mới thì hiện banner **"Đã có bản mới
vX.Y.Z"** + ghi chú, nút **"⬇ Tải bản mới"** mở link tải file ZIP,
nút **"Để sau"** ẩn banner cho tới khi có bản mới hơn nữa. Không có
mạng hoặc server chưa có thông tin thì im lặng, không báo lỗi. Nút
**"Kiểm tra cập nhật"** ở cuối popup kiểm tra ngay, bỏ qua cache 6 giờ.

Cách phát hành bản mới (để banner hiện cho người dùng cũ):
1. Tăng `version` trong `manifest.json` (và tiêu đề popup).
2. Đóng ZIP mới từ thư mục này (không gồm `lists/` và `tools/`).
3. Copy ZIP vào `doc-helper/license-server/downloads/`.
4. Sửa `doc-helper/license-server/latest-blueberry.json`
   (`version`, `url` trỏ tới file ZIP vừa copy, `notes`).
5. Redeploy license server lên Hostinger (server đọc file này 1 lần
   lúc khởi động, bản 1.3.3 trở lên mới có endpoint `/api/latest-blueberry`).

## Mới trong v2.2.0 — Đổi tên + màu việt quất + sửa lỗi từ đợt rà soát

## Mới trong v2.2.0 — Đổi tên + màu việt quất + sửa lỗi từ đợt rà soát

- Đổi tên thành **Blueberry ADS Block**, toàn bộ giao diện (popup, nút
  nguồn, badge, nút tải video) chuyển sang màu việt quất: chính
  `#5B4FCF`, đậm `#4535B0`, nhạt `#E8E6F9`. Icon mới: ô vuông bo góc
  gradient tím việt quất, chữ B trắng.
- Sửa lỗi đếm sai ở content script: bộ đếm "đã chặn hôm nay" / "khung
  QC đã ẩn" trước đây chỉ gửi báo cáo khi tổng đúng bội số của 5 nên
  hay bị thiếu; giờ gửi khi đủ 5 rồi reset, số đếm khớp thực tế.
- Thêm xử lý quảng cáo trong feed YouTube Shorts
  (`ytd-reel-video-renderer` có nhãn Quảng cáo/Sponsored sẽ bị ẩn).

Kết quả rà soát tính năng (22/11, bản 2.1.1 đã cài thành công):
chặn mạng DNR 52.741 rule (3 ruleset, 3 chế độ + bật/tắt lẻ), ẩn
khung quảng cáo bằng CSS + JS quét DOM, YouTube tua nhanh + tắt tiếng
+ tự bấm Bỏ qua, tải video FB/IG/TikTok/X/Threads, whitelist theo
site, nút nguồn, badge đếm theo ngày — đều chạy đúng thiết kế.
Giới hạn đã biết: số "đã chặn hôm nay" chỉ đếm khung đã ẩn + QC
YouTube đã bỏ qua, không đếm được request mạng bị DNR chặn vì Chrome
không cho extension biết con số đó.

## Mới trong v2.1.1 — Sửa lỗi load "rule with id 27302" (urlFilter)

Lỗi Chrome báo: `rules-ads.json: Rule with id 27302 specifies an
incorrect value for the 'urlFilter' key`. Nguyên nhân: rule đó có
urlFilter `||*.servimg.com/u/f45` — bắt đầu bằng `||*`, mà Chrome
cấm rõ trong tài liệu DNR ("A pattern beginning with `||*` is not
allowed. Use `*` instead"). Đợt kiểm tra trước chỉ rà regex và ký tự
lạ nên lọt mất trường hợp này.

Lần này rà soát **toàn bộ 52.742 rule** bằng script kiểm tra độc lập
(không dùng chung hàm validate của bộ biên dịch) và sửa tận gốc trong
`tools/convert.py` (`normalize_url_filter` + validate chặt):

- 1 rule `||*.servimg.com/u/f45` (id 27302) → `*.servimg.com/u/f45`.
- 175 rule có `*` trong phần host sau `||` (vd `||google.*/url?`,
  `||cacheserve.*/promodisplay`, `||geotargetly-api-*.com`) — Chrome
  phân tích phần host của pattern `||` nên `*` ở đó có thể bị từ
  chối; đã viết lại thành pattern thường `*google.*/url?` (vẫn chặn
  đúng URL đó, chỉ bỏ neo domain).
- 9 rule `*://` có `*` giữa nhãn host (vd `*://ad-api-*`) → viết
  lại thành pattern thường.
- 1 rule `||etwun.com:8080/counter.php?` (cổng trong host `||`) →
  pattern thường.
- 1 rule `||[::]` (không phải host thật) → bỏ hẳn, tổng còn 52.741 rule.
- Sửa lỗi viết thừa `**` ở lần biên dịch đầu (rule 27302 suýt thành
  `**.servimg.com/...`).

Kiểm tra độc lập sau khi biên dịch lại: **0 lỗi** trên cả 3 file rule
(không `||*`, không `*` trong host `||`, không `:`/`[` trong host
`||`, không ký tự không phải ASCII, không `\`, không `|` giữa pattern,
không regex, không `main_frame`, domain khởi tạo hợp lệ, ID liên tục
1..N). Tổng: ads 27.618, privacy 25.071, annoyance 52.

## Mới trong v2.1.0 — Tải video mạng xã hội

Mở Facebook, Instagram, TikTok, X hoặc Threads: mỗi video có nút
**“⬇ Tải video”** ở góc phải, bấm là tải file mp4 về máy, đúng chất
lượng đang xem. Hoặc bấm chuột phải vào video → **“Tải video này”**,
hoặc mở popup của extension để thấy danh sách video trên trang rồi bấm Tải.

- Video link trực tiếp (mp4) → tải bằng `chrome.downloads`.
- Video dạng blob (TikTok, một số video Facebook) → content script fetch
  blob rồi tải về, vì link blob chỉ có nghĩa trong tab đang mở.
- Video chưa load link (feed lazy-load) → extension tự bấm play rồi thử
  lại sau 800ms.
- File lưu tên dạng `facebook-2026-11-22-ten-trang.mp4`, vào thư mục
  Downloads mặc định của Chrome.

Giới hạn, nói thẳng:
- **Không tải video YouTube**: video YouTube dùng DASH (nhiều mảnh riêng
  lẻ, không có 1 file mp4 trực tiếp) và điều khoản YouTube cấm tải.
  Trên YouTube extension chỉ bỏ qua quảng cáo như trước.
- **Không tải livestream** dạng m3u8 / HLS (đang phát trực tiếp, không có
  file hoàn chỉnh để tải).
- Chất lượng file tải = chất lượng đang phát trên trang (đang xem 720p
  thì tải về 720p, muốn nét hơn thì chỉnh chất lượng video lên trước khi tải).
- Chỉ tải video để xem cá nhân, tôn trọng bản quyền và điều khoản của
  từng nền tảng.

## Chặn quảng cáo (giữ nguyên từ v2.0.1)

Extension chặn quảng cáo nhẹ, chạy bằng tính năng chặn sẵn có của Chrome
(Manifest V3, `declarativeNetRequest`). Chrome tự chặn ở tầng trình duyệt,
extension không cần chạy code cho từng request nên service worker gần như ngủ.

## Bộ lọc — một bộ duy nhất, tổng hợp từ nhiều nguồn

Nhiều danh sách lọc cộng đồng (quảng cáo chung, quảng cáo Việt Nam, theo
dõi, phiền nhiễu) được tải về, khử trùng lặp rồi gộp theo chức năng thành
3 nhóm, biên dịch ngày 22/11/2026:

| Nhóm | Rule | Mặc định |
|---|---|---|
| Chặn quảng cáo | 27.618 | Bật |
| Chặn theo dõi | 25.072 | Bật |
| Chặn nội dung phiền nhiễu | 52 | Tắt |

Tổng: **52.741 rule**. Cosmetic: 1.500 selector chung (`content/cosmetic.css`)
+ 1.318 domain riêng (`content/cosmetic.json`).

Chế độ trong popup:
- **Basic** = chỉ chặn quảng cáo: 27.618 rule, trong mức Chrome đảm bảo 30.000.
- **Optimal** (mặc định, khuyên dùng) = + chặn theo dõi: 52.689 rule.
- **Complete** = tất cả: 52.741 rule.
  Optimal và Complete dùng chung pool 330.000 rule của Chrome, nên chỉ cài
  riêng extension này, không cài thêm blocker khác (kẻo Chrome rớt rule lặng lẽ).

## Sửa lỗi v2.0.0 — không load được extension

Bản 2.0.0 Chrome báo một rule có giá trị `regexFilter` không hợp lệ
(rule id 250) và từ chối load cả extension. Nguyên nhân: một rule regex
trong danh sách gốc kết thúc bằng dấu `\` lẻ (do dấu `/` được escape trong
pattern gốc), không hợp lệ theo chuẩn RE2 của Chrome. Một rule lỗi là đủ
làm hỏng cả file.

Bản 2.0.1 sửa dứt điểm:
- **Bỏ toàn bộ rule regex** (chỉ 17 rule trên tổng số hơn 88.000 dòng gốc).
  Không còn `regexFilter` trong bất kỳ file rule nào, Chrome không còn gì
  để chê.
- **Rà soát domain giới hạn** (`$domain=`): bỏ các giá trị không phải tên
  miền hợp lệ như `wayfair.*`, `[::1]`, `localhost` — những giá trị này
  cũng làm Chrome từ chối ruleset.
- **Bộ biên dịch tự kiểm tra** trước khi xuất file: id liên tiếp từ 1,
  không `regexFilter`, không ký tự `^` trong `urlFilter`, không chặn
  `main_frame`, domain hợp lệ. Kiểm tra không qua thì không sinh file.

## Những gì KHÔNG chuyển được sang DNR (nói thẳng)

Biên dịch từ 88.612 dòng gốc, chỉ giữ được 52.741 rule mạng:
- Regex — bỏ hết, như trên.
- Scriptlet / `$replace` / `$redirect` / `$csp` / `$cookie` — MV3 không cho
  nên bỏ. Quảng cáo video YouTube vì vậy vẫn xử lý bằng cách tua nhanh +
  bấm Bỏ qua trong `content/youtube.js`, như v1.
- Rule chỉ ẩn element (`$ghide`...) — bỏ, không chuyển thành rule cho phép
  mạng để khỏi vô tình cho quảng cáo qua.
- Cosmetic có `:has()`, `:contains`, `:xpath` — bỏ, chỉ giữ selector đơn giản.

File `tools/convert.py` là bộ biên dịch, chạy lại được bất cứ lúc nào:
`python3 tools/convert.py` — nó biên dịch lại list rồi sinh lại 3 file
`rules-*.json` + `cosmetic.css` + `cosmetic.json`. Thư mục `lists/` là list
gốc tải về, không đóng gói vào extension.

## Cài đặt

1. Gỡ bản cũ (v1 và v2.0.0 nếu đã cài) trong `chrome://extensions/` để khỏi
   chạy 2 blocker cùng lúc.
2. Giải nén `adblocker-v2.0.1.zip` → thư mục `adblocker-v2`.
3. Chrome → `chrome://extensions/` → bật **Developer mode** →
   **Load unpacked** → chọn thư mục `adblocker-v2`.
4. Mở popup (nút nguồn ⏻) để đổi chế độ Basic / Optimal / Complete.

## Cấu trúc

```
adblocker-v2/
├── manifest.json        # MV3, 3 ruleset DNR
├── rules-ads.json       # Chặn quảng cáo, 27.618
├── rules-privacy.json   # Chặn theo dõi, 25.072
├── rules-annoyance.json # Phiền nhiễu, 52
├── background.js        # Chế độ, bật/tắt nhóm lọc, whitelist, đếm
├── content/
│   ├── content.js       # Ẩn khung QC + cosmetic theo từng site
│   ├── content.css / cosmetic.css
│   ├── cosmetic.json    # 1.318 domain
│   ├── youtube.js / youtube.css
├── popup/               # Nút nguồn, chế độ, từng nhóm lọc, số đã chặn
├── icons/
├── tools/convert.py     # Bộ biên dịch list -> DNR (không ship)
└── lists/               # List gốc (không ship)
```

Không server, không thu thập dữ liệu, không gọi mạng ra ngoài.
