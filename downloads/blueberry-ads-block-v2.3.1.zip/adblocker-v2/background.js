// Blueberry ADS Block v2 — background (MV3)
// Một bộ lọc duy nhất, tổng hợp từ nhiều danh sách cộng đồng rồi gộp
// theo chức năng thành 3 ruleset: quảng cáo / theo dõi / phiền nhiễu.
// 3 chế độ Basic / Optimal / Complete, whitelist, đếm số đã chặn.
const RULESETS = {
  "ads":       { label: "Chặn quảng cáo",             count: 27618 },
  "privacy":   { label: "Chặn theo dõi",              count: 25071 },
  "annoyance": { label: "Chặn nội dung phiền nhiễu", count: 52 },
};
const MODES = {
  basic:    ["ads"],
  optimal:  ["ads", "privacy"],
  complete: ["ads", "privacy", "annoyance"],
};
const DEFAULT_RULESETS = { ads: true, privacy: true, annoyance: false };
const DEFAULTS = {
  enabled: true, mode: "optimal", rulesets: DEFAULT_RULESETS,
  whitelist: [], blockedToday: 0, adsSkipped: 0, elementsHidden: 0,
  lastReset: new Date().toDateString(), listsVersion: "2026-11-22",
};

chrome.runtime.onInstalled.addListener(async () => {
  const cur = await chrome.storage.local.get(Object.keys(DEFAULTS));
  const patch = {};
  for (const [k, v] of Object.entries(DEFAULTS)) if (cur[k] === undefined) patch[k] = v;
  if (Object.keys(patch).length) await chrome.storage.local.set(patch);
  await applyRulesets();
  updateBadge();
  // Menu chuột phải trên video: tải video đang bấm phải
  try {
    chrome.contextMenus.removeAll(() => {
      chrome.contextMenus.create({ id: "download-video", title: "Tải video này", contexts: ["video"] });
    });
  } catch (e) {}
});

function safeFilename(name) {
  return (name || "video.mp4").replace(/[\\/:*?"<>|]+/g, "").slice(0, 120) || "video.mp4";
}
function downloadFile(url, filename) {
  return new Promise((resolve) => {
    try {
      chrome.downloads.download({ url, filename: safeFilename(filename), saveAs: false }, (id) => {
        resolve({ ok: !chrome.runtime.lastError, downloadId: id, error: chrome.runtime.lastError && chrome.runtime.lastError.message });
      });
    } catch (e) { resolve({ ok: false, error: String(e) }); }
  });
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== "download-video" || !info.srcUrl) return;
  if (info.srcUrl.startsWith("blob:")) {
    // Link blob chỉ có nghĩa trong tab đang mở: nhờ content script tải
    if (tab?.id) chrome.tabs.sendMessage(tab.id, { type: "download-blob", url: info.srcUrl });
    return;
  }
  downloadFile(info.srcUrl, `video-${new Date().toISOString().slice(0, 10)}.mp4`);
});
chrome.runtime.onStartup.addListener(async () => { await applyRulesets(); updateBadge(); scheduleUpdateCheck(); });

// --- Báo bản mới tự động (không cần mở popup): kiểm tra định kỳ bằng
// alarm, có bản mới thì hiện thông báo Chrome với 2 nút Tải / Để sau.
// NÓI THẲNG: extension cài tay (Load unpacked) thì Chrome KHÔNG cho tự
// update thầm lặng — không có API nào để extension tự thay file của
// chính nó. Thông báo tự động + 1 bấm tải ZIP là mức tối đa làm được;
// sau khi tải về vẫn cần giải nén đè lên thư mục cũ rồi bấm Reload trong
// chrome://extensions/. Muốn update hoàn toàn tự động thì chỉ có cách
// đăng lên Chrome Web Store (Chrome tự update), nhưng lên Store thì phải
// khai Trader + privacy policy tên thật — đúng lý do đã không lên Store
// với Doc Helper. Chung 1 khóa cache với popup (bb_update_check).
const UPDATE_URL = 'https://license.digimar.site/api/latest-blueberry';
const UPDATE_CACHE_TTL = 6 * 60 * 60 * 1000;
function compareVersions(a, b) {
  const pa = String(a || '').split('.').map((x) => parseInt(x, 10) || 0);
  const pb = String(b || '').split('.').map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d > 0 ? 1 : -1;
  }
  return 0;
}
async function checkUpdateBackground() {
  let info = {};
  try { info = (await chrome.storage.local.get('bb_update_check')).bb_update_check || {}; } catch (e) {}
  if (info.checkedAt && (Date.now() - info.checkedAt) < UPDATE_CACHE_TTL && info.latest) return;
  let latest = null;
  try {
    const res = await fetch(UPDATE_URL);
    if (res && res.ok) {
      const data = await res.json();
      if (data && data.ok && data.version && data.url) {
        latest = { version: data.version, url: data.url, notes: data.notes || '' };
      }
    }
  } catch (e) { latest = null; }
  try { await chrome.storage.local.set({ bb_update_check: { checkedAt: Date.now(), latest, dismissedVersion: info.dismissedVersion || '' } }); } catch (e) {}
  if (!latest) return;
  const current = chrome.runtime.getManifest().version || '';
  if (compareVersions(latest.version, current) <= 0) return;
  if (info.dismissedVersion === latest.version) return;
  try {
    await chrome.notifications.create('bb-update', {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: 'Blueberry ADS Block — Đã có bản mới v' + latest.version,
      message: (latest.notes ? latest.notes + ' ' : '') + 'Bấm để tải bản mới về.',
      buttons: [{ title: '⬇ Tải bản mới' }, { title: 'Để sau' }],
    });
  } catch (e) {}
}
function scheduleUpdateCheck() {
  try { chrome.alarms.create('bb-update-check', { delayInMinutes: 5, periodInMinutes: 360 }); } catch (e) {}
}
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'bb-update-check') checkUpdateBackground();
});
async function openLatestDownload() {
  let info = {};
  try { info = (await chrome.storage.local.get('bb_update_check')).bb_update_check || {}; } catch (e) {}
  const url = info.latest && info.latest.url;
  if (url) chrome.tabs.create({ url });
}
async function dismissLatest() {
  let info = {};
  try { info = (await chrome.storage.local.get('bb_update_check')).bb_update_check || {}; } catch (e) {}
  if (info.latest) {
    try { await chrome.storage.local.set({ bb_update_check: { ...info, dismissedVersion: info.latest.version } }); } catch (e) {}
  }
}
chrome.notifications.onClicked.addListener((id) => {
  if (id !== 'bb-update') return;
  openLatestDownload();
  try { chrome.notifications.clear(id); } catch (e) {}
});
chrome.notifications.onButtonClicked.addListener((id, btnIdx) => {
  if (id !== 'bb-update') return;
  if (btnIdx === 0) openLatestDownload(); else dismissLatest();
  try { chrome.notifications.clear(id); } catch (e) {}
});

async function getSettings() {
  const s = await chrome.storage.local.get(Object.keys(DEFAULTS));
  const merged = { ...DEFAULTS, ...s, rulesets: { ...DEFAULT_RULESETS, ...(s.rulesets || {}) } };
  return merged;
}
async function maybeResetDaily() {
  const s = await getSettings();
  const today = new Date().toDateString();
  if (s.lastReset !== today) {
    await chrome.storage.local.set({ blockedToday: 0, adsSkipped: 0, elementsHidden: 0, lastReset: today });
  }
}
function enabledIds(s) {
  if (!s.enabled) return [];
  return Object.keys(RULESETS).filter(id => s.rulesets[id]);
}
async function applyRulesets() {
  const s = await getSettings();
  const on = enabledIds(s);
  const off = Object.keys(RULESETS).filter(id => !on.includes(id));
  try {
    await chrome.declarativeNetRequest.updateEnabledRulesets({ enableRulesetIds: on, disableRulesetIds: off });
  } catch (e) { console.warn("[Blueberry] updateEnabledRulesets:", e); }
  await syncWhitelistRules(s.whitelist);
}
async function syncWhitelistRules(whitelist) {
  try {
    const existing = await chrome.declarativeNetRequest.getDynamicRules();
    const addRules = (whitelist || []).slice(0, 50).map((host, i) => ({
      id: 1000 + i, priority: 100, action: { type: "allow" },
      condition: { urlFilter: `||${host.replace(/^www\./, "")}`, resourceTypes: ["main_frame","sub_frame","script","image","xmlhttprequest","stylesheet","font","media","websocket","other"] }
    }));
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: existing.map(r => r.id), addRules });
  } catch (e) { console.warn("[Blueberry] whitelist:", e); }
}
function updateBadge() {
  chrome.storage.local.get(["enabled", "blockedToday"], (s) => {
    const enabled = s.enabled !== false;
    chrome.action.setBadgeText({ text: enabled ? String(Math.min(99, s.blockedToday || 0)) : "OFF" });
    chrome.action.setBadgeBackgroundColor({ color: enabled ? "#5B4FCF" : "#6b7280" });
  });
}
async function setMode(mode) {
  if (!MODES[mode]) return null;
  const rulesets = {};
  for (const id of Object.keys(RULESETS)) rulesets[id] = MODES[mode].includes(id);
  await chrome.storage.local.set({ mode, rulesets });
  await applyRulesets(); updateBadge();
  return { mode, rulesets };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    await maybeResetDaily();
    const s = await getSettings();
    if (msg.type === "ad-blocked") {
      const n = msg.count || 1;
      await chrome.storage.local.set({ blockedToday: s.blockedToday + n, elementsHidden: s.elementsHidden + n });
    } else if (msg.type === "yt-ad-skipped") {
      await chrome.storage.local.set({ blockedToday: s.blockedToday + 1, adsSkipped: s.adsSkipped + 1 });
    } else if (msg.type === "download-video") {
      sendResponse(await downloadFile(msg.url, msg.filename)); return;
    } else if (msg.type === "get-state") {
      const host = sender.tab?.url ? new URL(sender.tab.url).hostname : "";
      sendResponse({ ...s, rulesetMeta: RULESETS, currentHost: host, whitelisted: s.whitelist.includes(host), totalRules: enabledIds(s).reduce((a, id) => a + RULESETS[id].count, 0) });
      return;
    } else if (msg.type === "toggle-enabled") {
      const enabled = !s.enabled;
      await chrome.storage.local.set({ enabled });
      await applyRulesets(); updateBadge();
      sendResponse({ enabled }); return;
    } else if (msg.type === "set-mode") {
      sendResponse(await setMode(msg.mode)); return;
    } else if (msg.type === "toggle-ruleset") {
      const rulesets = { ...s.rulesets, [msg.id]: !s.rulesets[msg.id] };
      // Chế độ tự chuyển thành "custom" khi bật/tắt lẻ từng list
      const mode = Object.entries(MODES).find(([, ids]) => ids.every(id => rulesets[id]) && Object.keys(RULESETS).every(id => rulesets[id] === ids.includes(id)))?.[0] || "custom";
      await chrome.storage.local.set({ rulesets, mode });
      await applyRulesets(); updateBadge();
      sendResponse({ rulesets, mode }); return;
    } else if (msg.type === "toggle-whitelist") {
      const host = msg.host;
      if (!host) { sendResponse({ ok: false }); return; }
      let wl = [...s.whitelist];
      const i = wl.indexOf(host);
      if (i >= 0) wl.splice(i, 1); else wl.push(host);
      await chrome.storage.local.set({ whitelist: wl });
      await syncWhitelistRules(wl);
      sendResponse({ ok: true, whitelisted: wl.includes(host), whitelist: wl }); return;
    }
    updateBadge();
    sendResponse({ ok: true });
  })();
  return true;
});
chrome.storage.onChanged.addListener((changes) => {
  if (changes.enabled || changes.rulesets || changes.mode) { applyRulesets(); updateBadge(); }
});
